from django.contrib import admin
from studentinfo.models import Studentdetails, Coursedetails


# Register your models here.

admin.site.register(Studentdetails)
admin.site.register(Coursedetails)
