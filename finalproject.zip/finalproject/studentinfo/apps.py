from django.apps import AppConfig


class StudentinfoConfig(AppConfig):
    name = 'studentinfo'
