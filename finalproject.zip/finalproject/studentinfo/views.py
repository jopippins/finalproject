from django.shortcuts import render
from django.http import HttpResponse
from studentinfo.models import Studentdetails, Coursedetails
from django.core.paginator import Paginator
from django.contrib.auth.decorators import login_required

# Create your views here.

@login_required
def home(request):
    return render(request, 'studentinfo/home.html')

@login_required
def studentdetails(request):
    studentdetailsdata = Studentdetails.objects.all()
    paginator = Paginator(studentdetailsdata, 10)
    page = request.GET.get('page')
    studentdetailsminiset = paginator.get_page(page)
    return render(request, 'studentinfo/studentdetails.html', {'data' :studentdetailsminiset})

@login_required
def studentenrollment(request):
    return render(request, 'studentinfo/studentenrollment.html')

@login_required
def coursedetails(request):
    coursedetailsdata = Coursedetails.objects.all()
    paginator = Paginator(coursedetailsdata, 10)
    page = request.GET.get('page')
    coursedetailsminiset = paginator.get_page(page)
    return render(request, 'studentinfo/coursedetails.html', {'data' :coursedetailsminiset})
    
